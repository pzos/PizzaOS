#define vga_start 0xB8000
#define vga_extent 80 * 25

#define textStyle_white_black 0x0F

typedef struct __attribute__((packed)) {
    char character;
    char style;
} vga_char;

volatile vga_char *textArea = (vga_char*) vga_start;

void clear_console() {
    vga_char clear_char = {
        .character=' ',
        .style=textStyle_white_black
    };

    for(unsigned long long int i = 0; i < vga_extent; i++) {
        textArea[i] = clear_char;
    }
}

void print(const char *str) {
    for(unsigned long long int i = 0; str[i] != '\0'; i++) {
        if (i >= vga_extent)
            break;

        vga_char temp = {
            .character=str[i],
            .style=textStyle_white_black
        };

        textArea[i] = temp;
    }
}

int main() {
    clear_console();
    const char *buildNumber = "Build 1";
    const char *loadedKernelMessage = "krnl: Loaded kernel2";
    print(buildNumber);
    print(loadedKernelMessage);

    return 0;
}