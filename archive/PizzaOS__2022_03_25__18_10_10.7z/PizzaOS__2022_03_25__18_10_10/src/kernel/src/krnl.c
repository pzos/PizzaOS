#include <cpu/ports.h>
#include <driver/vga.h>

int main() {
    clear_console(color_white, color_black);
    const char *msg_loadedKernel = "krnl: Loaded kernel. sugd";
    print_str(msg_loadedKernel, color_white, color_cyan);

    return 0;
}