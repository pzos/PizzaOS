#include <cpu/ports.h>
#include <driver/vga.h>

int main() {
    clear_console();
    const char *msg_loadedKernel = "krnl: Loaded kernel. Va";
    print_str(msg_loadedKernel);

    return 0;
}