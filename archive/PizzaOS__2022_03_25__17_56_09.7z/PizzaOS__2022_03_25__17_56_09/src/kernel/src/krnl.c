#include <cpu/ports.h>
#include <driver/vga.h>

int main() {
    clear_console(color_yellow, color_yellow);
    const char *msg_loadedKernel = "krnl: Loaded kernel. Vagg";
    print_str(msg_loadedKernel);

    return 0;
}